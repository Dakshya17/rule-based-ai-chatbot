"""
test_chatbot.py
----------------
Basic unit tests for the rule-based chatbot's knowledge base.
Run with:  python -m unittest discover
"""

import sys
import os
import unittest

# Allow importing knowledge_base.py from the parent directory
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from knowledge_base import get_response, INTENTS, FALLBACK_RESPONSES


class TestKnowledgeBase(unittest.TestCase):

    def test_greeting_intent(self):
        response = get_response("hello")
        self.assertIn(response, INTENTS["greeting"]["responses"])

    def test_greeting_substring_match(self):
        # "hi" should still be detected inside a longer sentence
        response = get_response("hi there rulebot")
        self.assertIn(response, INTENTS["greeting"]["responses"])

    def test_farewell_intent(self):
        response = get_response("goodbye")
        self.assertIn(response, INTENTS["farewell"]["responses"])

    def test_thanks_intent(self):
        response = get_response("thank you")
        self.assertIn(response, INTENTS["thanks"]["responses"])

    def test_unknown_input_returns_fallback(self):
        response = get_response("asdkjqwlekjasd")
        self.assertIn(response, FALLBACK_RESPONSES)

    def test_at_least_five_intents_defined(self):
        # Project spec requires 5+ intents in the knowledge base
        self.assertGreaterEqual(len(INTENTS), 5)


if __name__ == "__main__":
    unittest.main()
